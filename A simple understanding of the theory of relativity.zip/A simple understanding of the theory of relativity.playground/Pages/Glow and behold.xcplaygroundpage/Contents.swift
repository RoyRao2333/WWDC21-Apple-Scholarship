//: ## ☪︎ Glow and behold!
/*:
 ___
- Important:
__This is the epilogue of my Playground__. Thank you for your patience and I wish you had a great time! :) 
 ___
*/

/*:
The vastness of the universe is beyond our imagination.

As long as mankind continues to develop, things that we dare not think of now will gradually become a reality, and we are bound to go farther and farther in the universe. Human beings will not be bound in the cradle of the earth, the sea of ​​stars are waiting for us!
*/

//: [Previous Chapter](Interstellar%20travel%20and%20more)
